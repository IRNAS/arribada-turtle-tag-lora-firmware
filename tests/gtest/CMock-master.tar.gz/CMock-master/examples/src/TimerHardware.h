#ifndef _TIMERHARDWARE_H
#define _TIMERHARDWARE_H

#include "Types.h"

void TimerHardware_Init(void);

#endif // _TIMERHARDWARE_H
