#ifndef _ADCHARDWARECONFIGURATOR_H
#define _ADCHARDWARECONFIGURATOR_H

#include "Types.h"

void Adc_Reset(void);
void Adc_ConfigureMode(void);
void Adc_EnableTemperatureChannel(void);

#endif // _ADCHARDWARECONFIGURATOR_H
