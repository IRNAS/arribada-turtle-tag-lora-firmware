#ifndef _USARTCONDUCTOR_H
#define _USARTCONDUCTOR_H

void UsartConductor_Init(void);
void UsartConductor_Run(void);

#endif // _USARTCONDUCTOR_H
